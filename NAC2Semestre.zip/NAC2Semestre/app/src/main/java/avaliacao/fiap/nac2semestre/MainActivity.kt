package avaliacao.fiap.nac2semestre

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //TODO adicionar click do botão
        //TODO recuperar texto da view EditText
        //TODO chamar tela MeusFilmes passando o texto recuperado do edit text

    }

}
