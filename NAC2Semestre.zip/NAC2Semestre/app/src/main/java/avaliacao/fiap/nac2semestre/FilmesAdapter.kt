package avaliacao.fiap.nac2semestre

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class FilmesAdapter : ListAdapter<Filme, FilmesAdapter.FilmeViewHolder>(FilmesDiffUtils()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmeViewHolder {
      //TODO carregar o arquivo de layout
    }

    override fun onBindViewHolder(holder: FilmeViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    //TODO
    /**
     * Mapear os campos do arquivo de layout item_filmes_layout
     */
    class FilmeViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView)  {

        fun bind(filme : Filme){

        }
    }

    class FilmesDiffUtils : DiffUtil.ItemCallback<Filme>(){
        override fun areItemsTheSame(oldItem: Filme, newItem: Filme): Boolean {
            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        override fun areContentsTheSame(oldItem: Filme, newItem: Filme): Boolean {
            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

    }
}